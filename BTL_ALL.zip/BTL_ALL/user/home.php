<!DOCTYPE html>
<html lang="en">
<head>
	<title>Document</title>
	<?php 
	include '../templates/css.php';
	include '../templates/js.php';
	 ?>

</head>
<body>

<?php 
    include '../templates/header.php'
 ?>
</body>
</html>