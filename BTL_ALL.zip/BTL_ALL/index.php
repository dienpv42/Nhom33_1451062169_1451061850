<?php
header("Location: user/home.php");