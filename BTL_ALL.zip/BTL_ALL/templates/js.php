	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/jquery.countdown.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>