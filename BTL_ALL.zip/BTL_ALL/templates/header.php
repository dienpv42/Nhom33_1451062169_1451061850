<div class="header">
	<div class="header-top">
	    <div class="container">
	        <div class="dndk">
	        	<ul class="last" id="top_register">
	        		<li class="users"><a href="../user/login.php">Đăng Nhập</a></li>
	        		<li class="users"><a href="../customer/register.php">Đăng Ký</a></li>
<!-- 	        		<li class="language-vn active"><a href=""></a></li>
<li class="language-vn en"><a href=""></a></li> -->
	        	</ul>
	        </div>
	    </div>
	</div>
    <div class="header-buttom">
        <div class="container">
		    <div class="col-lg-4">
		  	    <img class="logo" src="../images/cgvlogo.png" alt="">
		    </div>
		    <div class="col-md-8">
		        <div id="menu">
		            <ul class="lv1">
                        <li class="it"><a class="lv2" href="">PHIM</a>
                            <ul class="sub-menu">
                        <li class="it2"><a href="">Phim Đang Chiếu</a></li>
                        <li class="it2"><a class="lv4" href="">Phim Sắp Chiếu</a></li>
                            </ul>
                        </li>
                        <li class="it"><a class="lv2" href="">LỊCH CHIẾU</a></li>
                        <li class="it"><a class="lv2" href="">Rạp CGV</a></li>
                        <li class="it"><a class="lv2" href="">THÀNH VIÊN</a>
                            <ul class="sub-menu">
                                <li class="it2"><a href="">Thành Viên</a></li>
                                <li class="it2"><a class="lv4" href="">Đăng Ký<a></li>
                            </ul>
                        </li>
                    </ul>
	  	        </div>
	  	    </div>
        </div>
    </div>
</div>