<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<div class="col-md-12"><h1 style="text-align: center;">Trang đang cập nhập</h1></div>
	
</body>
</html>